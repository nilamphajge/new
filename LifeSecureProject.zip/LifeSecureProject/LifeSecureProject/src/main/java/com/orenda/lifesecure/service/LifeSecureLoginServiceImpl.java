package com.orenda.lifesecure.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import com.orenda.lifesecure.dao.LifeSecureLoginDao;
import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Service
public class LifeSecureLoginServiceImpl implements LifeSecureLoginService {

	@Autowired
	LifeSecureLoginDao loginDao;
//	private static final Logger logger=LoggerFactory.logger(LifeSecureLoginServiceImpl.class);

	@Override
//	@Transactional(readOnly = true)
	public boolean verifyUser(String useremail, String password) {
		// TODO Auto-generated method stub

		User user = loginDao.verifyUser(useremail);
		System.out.println("service");

		if (user != null && user.getPassword().equals(password)) {
			return true;
		}

		return false;
	}
	@Override
	public boolean saveUserDetails(UserDetails userdetails) {

		boolean flag1 = loginDao.saveUserData(userdetails);
		if (flag1) {
			User user = new User();
			user.setPassword(user.getPassword());
			user.setEmail(userdetails.getEmail());
			boolean flag = loginDao.saveUsername(user);

			System.out.println(flag);
			return true;
		}

		return false;
	}

}
