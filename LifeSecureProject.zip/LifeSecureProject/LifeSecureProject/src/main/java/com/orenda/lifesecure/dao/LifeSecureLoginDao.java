package com.orenda.lifesecure.dao;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

public interface LifeSecureLoginDao {

	User verifyUser(String useremail);

	boolean saveUserData(UserDetails userdetails);

	boolean saveUsername(User user);

}
