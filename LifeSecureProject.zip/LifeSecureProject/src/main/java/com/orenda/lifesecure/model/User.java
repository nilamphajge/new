package com.orenda.lifesecure.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "tbl_login")
public class User {

	@Id
	
	@Column(name = "login_id")
	private int id;
	@Column(name = "user_email")
	private String email;

	@Column(name = "user_password")
	private String password;
	@Column(name = "ip_address")
	private String ip_address;
	@Column(name = "last_login")
	private String last_login;
	@Column(name = "updated_time")
	private String updated_time;
	@Column(name = "is_active")
	private int is_active;
	@Column(name = "pass_valid_from")
	private LocalDate pass_valid_from;
	@Column(name = "pass_valid_till")
	private LocalDate pass_valid_till;
	
		public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIp_address() {
		return ip_address;
	}

	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}

	public String getLast_login() {
		return last_login;
	}

	public void setLast_login(String last_login) {
		this.last_login = last_login;
	}

	public String getUpdated_time() {
		return updated_time;
	}

	public void setUpdated_time(String updated_time) {
		this.updated_time = updated_time;
	}

	public int getIs_active() {
		return is_active;
	}

	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}

	public LocalDate getPass_valid_from() {
		return pass_valid_from;
	}

	public void setPass_valid_from(LocalDate pass_valid_from) {
		this.pass_valid_from = pass_valid_from;
	}

	public LocalDate getPass_valid_till() {
		return pass_valid_till;
	}

	public void setPass_valid_till(LocalDate pass_valid_till) {
		this.pass_valid_till = pass_valid_till;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", password=" + password + ", ip_address=" + ip_address
				+ ", last_login=" + last_login + ", updated_time=" + updated_time + ", is_active=" + is_active
				+ ", pass_valid_from=" + pass_valid_from + ", pass_valid_till=" + pass_valid_till + "]";
	}
	
	
	
}
