package com.orenda.lifesecure.utility;

public class LifeSecureCommonUtility {

}
